const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d', { willReadFrequently: true });

function resize() {
  canvas.width = canvas.clientWidth;
  canvas.height = canvas.clientHeight;
}
addEventListener('resize', resize);
resize();

let analyser, dataArray, audioCtx;
async function initAudio() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const source = audioCtx.createMediaStreamSource(stream);
  analyser = audioCtx.createAnalyser();
  analyser.fftSize = 512;
  source.connect(analyser);
  dataArray = new Uint8Array(analyser.frequencyBinCount);
}
initAudio().catch(() => alert('Mic access is required for Synesthesia Canvas!'));

let mode = 0;
const modes = 4;
let hueBase = 0;

function averageAmplitude(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function drawNebula(freq) {
  ctx.fillStyle = `hsla(${hueBase}, 60%, 10%, .05)`;
  ctx.fillRect(0,0,canvas.width,canvas.height);
  const radius = (freq / 255) * (canvas.height / 4);
  ctx.beginPath();
  ctx.arc(Math.random()*canvas.width, Math.random()*canvas.height, radius, 0, Math.PI*2);
  ctx.fillStyle = `hsla(${hueBase}, 80%, 50%, .25)`;
  ctx.fill();
}

function drawLiquidPixels(freqArr){
  const imgData = ctx.getImageData(0,0,canvas.width,canvas.height);
  for(let i=0;i<imgData.data.length;i+=4){
    imgData.data[i]   *= .96;
    imgData.data[i+1] *= .96;
    imgData.data[i+2] *= .96;
  }
  ctx.putImageData(imgData,0,0);
  for(let i=0;i<50;i++){
    const x = Math.random()*canvas.width;
    const y = Math.random()*canvas.height;
    const band = freqArr[Math.floor(Math.random()*freqArr.length)];
    ctx.fillStyle = `hsla(${band+200}, 80%, 60%, 1)`;
    ctx.fillRect(x, y, 2, 2);
  }
}

function drawNeonBars(freqArr){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const barWidth = canvas.width / freqArr.length;
  freqArr.forEach((v,i)=>{
    const h = (v/255)*canvas.height;
    ctx.fillStyle = `hsl(${i*3 + hueBase}, 90%, 50%)`;
    ctx.fillRect(i*barWidth, canvas.height-h, barWidth, h);
  });
}

const particles=[];
class Particle{
  constructor(x,y,v){
    this.x=x;this.y=y;this.v=v;
    this.size = Math.random()*3+1;
    this.hue = Math.random()*360;
  }
  update(){
    this.x += Math.cos(this.v.dir)*this.v.speed;
    this.y += Math.sin(this.v.dir)*this.v.speed;
    this.size*=.99;
  }
  draw(){
    ctx.fillStyle=`hsla(${this.hue},100%,60%,.6)`;
    ctx.beginPath();ctx.arc(this.x,this.y,this.size,0,Math.PI*2);ctx.fill();
  }
}

function drawParticleSwirl(avg){
  ctx.fillStyle='rgba(0,0,0,.06)';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  if(particles.length<400){
    particles.push(new Particle(
      canvas.width/2, canvas.height/2,
      {dir:Math.random()*Math.PI*2, speed:avg/300+Math.random()*1.5}
    ));
  }
  particles.forEach((p,i)=>{
    p.update();p.draw();
    if(p.size<0.3 || p.x<0||p.y<0||p.x>canvas.width||p.y>canvas.height)
      particles.splice(i,1);
  });
}

function animate(){
  requestAnimationFrame(animate);
  if(!analyser) return;
  analyser.getByteFrequencyData(dataArray);
  const avg = averageAmplitude(dataArray);
  hueBase = (hueBase + .1) % 360;
  switch(mode){
    case 0: drawNebula(avg); break;
    case 1: drawLiquidPixels(dataArray); break;
    case 2: drawNeonBars(dataArray); break;
    case 3: drawParticleSwirl(avg); break;
  }
}
animate();

addEventListener('keydown',(e)=>{
  if(e.key.toLowerCase()==='m'){
    mode = (mode+1)%modes;
  }
  if(e.key.toLowerCase()==='s'){
    const link=document.createElement('a');
    link.download=`synesthesia_${Date.now()}.png`;
    link.href=canvas.toDataURL('image/png');
    link.click();
  }
});
